module.exports = [{
      plugin: require('/Users/boriscivcic/Documents/prisma/landingPages/gatsby-browser.js'),
      options: {"plugins":[]},
    }]
